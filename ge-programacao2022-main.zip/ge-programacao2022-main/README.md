# ge-programacao2022
Repositório para a formação SEED
Aqui neste  readme você deve seguir as regras :
💡😎
Terminar as atividades do Alura até julho. Comer alimentos saudaveis e ir ao colegio. 
